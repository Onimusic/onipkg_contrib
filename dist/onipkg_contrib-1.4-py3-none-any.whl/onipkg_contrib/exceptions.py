class InvalidFileNameError(Exception):
    pass
